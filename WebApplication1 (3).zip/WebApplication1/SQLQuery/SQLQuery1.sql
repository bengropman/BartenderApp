﻿INSERT INTO CocktailMenu (CocktailName, Price)
VALUES ('Mojito', 10), ('Martini', 12), ('Margarita', 11);