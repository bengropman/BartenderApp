﻿using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using BartenderApp.Models;

namespace BartenderApp.Controllers
{
    public class HomeController : Controller
    {
        private Cocktail cocktailModel;

        public HomeController()
        {
            cocktailModel = new Cocktail();
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Menu()
        {
            return View(cocktailModel.Menu);
        }

        [HttpPost]
        public IActionResult PlaceOrder(string cocktailName)
        {
            cocktailModel.AddOrder(cocktailName);
            return RedirectToAction("Menu");
        }

        public IActionResult Orders()
        {
            return View(cocktailModel.Orders);
        }
    }
}